package anotar;

public class Miclase {

    @Mianotacion(valor = "Ejemplo", numero = 5)
    public void miMetodo() {
        System.out.println("Método con anotación");
    }
}
